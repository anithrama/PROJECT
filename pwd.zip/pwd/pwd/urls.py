"""Plantation URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
https://docs.djangoproject.com/en/4.1/topics/http/urls/
Examples:
Function views
1. Add an import:  from my_app import views
2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
1. Add an import:  from other_app.views import Home
2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
1. Import the include() function: from django.urls import include, path
2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from pwdapp import views
from django.conf.urls.static import static
from django.conf import settings

urlpatterns = [
path('admin/', admin.site.urls),
path('',views.index),
path('index/',views.index),
path('login_action/', views.sign_in_process),
path('contractor_action/', views.contractor_action),
path('contractor_home/', views.contractor_home),

path('admin_home/', views.admin_home),
path('admin_logout/', views.admin_logout),

path('check_username/', views.check_username, name='check_username'),
path('display_district/', views.display_district, name='display_district'),
path('display_staff/', views.display_staff, name='display_staff'),


#registration
path('login/', views.login_page),
path('contractor_registration/', views.contractor_registration),
path('add_staff/', views.add_staff),
path('save_staff/', views.save_staff),
path('staff_list/', views.staff_list),
path('save_staff/', views.save_staff),
path('edit_staff/<int:id>', views.edit_staff),
path('update_staff/<int:id>', views.update_staff),
path('delete_staff/<int:id>', views.delete_staff),

#admin


path('approve_contractor/', views.approve_contractor),
path('approve/<int:id>', views.approve),
path('reject/<int:id>', views.reject),
path('contractor_list/', views.contractor_list),

path('add_category/', views.add_category),
path('save_category/', views.save_category),
path('edit_category/<int:id>', views.edit_category),
path('update_category/<int:id>', views.update_category),
path('delete_category/<int:id>', views.delete_category),

#Product
path('add_work_details/', views.add_work_details),
path('save_work/', views.save_work_details),
path('edit_work/<int:id>', views.edit_work),
path('update_work/<int:id>', views.update_work),
path('delete_work/<int:id>', views.delete_work),
path('work_list/', views.work_list),
path('allot_work/<int:id>', views.allot_work),
path('save_allot_work/<int:id>', views.save_allot_work),
path('alloted_work/', views.alloted_work),
path('finish_work/<int:id>', views.finish_work),
path('finished_work/', views.finished_work),

#Complaints
path('view_contractor_complaint/', views.view_complaints),
path('replied_contractor_complaint_list/', views.replied_list),
path('adm_reply_complaint/<int:id>', views.adm_reply_complaint),
path('add_reply/<int:id>', views.add_reply),

#  Customer
path('Complaint/', views.Complaint_frm),
path('save_complaint/', views.save_complaint),
path('Complaint_list/', views.Complaint_list),
path('delete_complaint/<int:id>', views.delete_complaint),

path('public_complaints/', views.public_complaints),
path('save_public_complaint/', views.save_public_complaint),

path('public_admin_complaints/', views.public_admin_complaints),
path('public_staff_complaints/', views.public_staff_complaints),


path('events/', views.view_events),

#Tender
path('add_tender/', views.add_tender),
path('save_tender/', views.save_tender),
path('view_tender/', views.view_tender),
path('tender_application/<int:id>', views.tender_application),
path('Allot_tender/<int:id>', views.Allot_tender),
path('save_allot_tender/<int:id>', views.save_allot_tender),

path('accepted_tender/', views.accepted_tender),

#Tender Customer
path('view_customer_tender/', views.view_customer_tender),
path('tender_request/<int:id>', views.tender_request),
path('save_cust_tender/<int:id>', views.save_cust_tender),
path('accepted_tenders/', views.accepted_tenders),


path('tender_details/', views.tender_details),
#Staff
path('staff_alloted_tender/', views.staff_alloted_tender),
path('staff_review_tender/<int:id>', views.staff_review_tender),
path('save_tender_work_review/<int:id>', views.save_tender_work_review),
path('staff_finished_tender/', views.staff_finished_tender),
path('staff_finished_review_tender/<int:id>', views.staff_finished_review_tender),

#Admin
path('staff_review/<int:id>', views.staff_review),
path('staff_review_reply_tender/<int:id>', views.staff_review_reply_tender),
path('save_tender_work_reply/<int:id>', views.save_tender_work_reply),


path('contractor_review_tender/<int:id>', views.contractor_review_tender),
path('save_contractor_work_update/<int:id>', views.save_contractor_work_update),
path('finished_contractor_tenders/', views.finished_contractor_tenders),
path('contractor_review_list/<int:id>', views.contractor_review_list),
path('contractor_progress_details/<int:id>', views.contractor_progress_details),
path('contractor_review_reply_tender/<int:id>', views.contractor_review_reply_tender),
path('save_tender_work_update_reply/<int:id>', views.save_tender_work_update_reply),

path('finish_tender_work/<int:id>', views.finish_tender_work),
path('finished_tender/', views.finished_tender),

path('contractor_progress_details_list/<int:id>', views.contractor_progress_details_list),
path('staff_review_list/<int:id>', views.staff_review_list),
# Staff
path('staff_home/', views.staff_home),
path('staff_alloted_work/', views.staff_alloted_work),





# Logout

path('user_logout/', views.user_logout),
]
if settings.DEBUG:
    urlpatterns+=static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)