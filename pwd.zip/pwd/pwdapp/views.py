from imaplib import _Authenticator
import random
from django.db import connection
from django.http import JsonResponse
from django.shortcuts import render
from django.shortcuts import render,redirect
from django.contrib import messages
from django.contrib.auth import authenticate
from django.contrib.auth.hashers import make_password
from django.contrib.auth import logout
from pwdapp.models import login,contractor_register,state,district,staff,category,complaint,tender,tender_quote,work,public_complaint,tender_review,tender_update_contractor
from django.core.files.storage import FileSystemStorage
from django.conf import settings
import os
# Create your views here.
def index(request):
    return render(request,'index.html')
def sign_in_process(request):
    u=request.POST.get("username")
    p=request.POST.get("password")
    obj=authenticate(username=u,password=p)
    if obj is not None:
        if obj.is_superuser == 1:
            request.session['suname'] = u
            request.session['slogid'] = obj.id
            return redirect('/admin_home/')
        else:
          messages.add_message(request, messages.INFO, 'Invalid User.')
          return redirect('/index/')
    else:
        newp=p
        try:
            obj1=login.objects.get(username=u,password=newp)

            if obj1.Usertype=="Staff":
                if(obj1.status=="Approved"):
                    request.session['suname'] = u
                    request.session['slogid'] = obj1.login_id
                    return redirect('/staff_home/')
                elif(obj1.status=="Not Approved"):
                  messages.add_message(request, messages.INFO, 'Waiting For Approval.')
                  return redirect('/login/')
                else:
                  messages.add_message(request, messages.INFO, 'Invalid User.')
                  return redirect('/login/')
            elif  obj1.Usertype=="Contractor":
                if(obj1.status=="Approved"):
                    request.session['suname'] = u
                    request.session['slogid'] = obj1.login_id
                    return redirect('/contractor_home/')
                elif(obj1.status=="Not Approved"):
                  messages.add_message(request, messages.INFO, 'Waiting For Approval.')
                  return redirect('/login/')
                else:
                  messages.add_message(request, messages.INFO, 'Invalid User.')
                  return redirect('/login/')
            else:
                 messages.add_message(request, messages.INFO, 'Invagfdlid User.')
                 return redirect('/login/')
        except login.DoesNotExist:
         messages.add_message(request, messages.INFO, 'Invalid User.')
         return redirect('/index/')
def admin_home(request):
    if 'suname' in request.session:
     return render(request,'Master/index.html')
    else:
      return redirect('/login/')
def staff_home(request):
    if 'suname' in request.session:
     return render(request,'Staff/index.html')
    else:
      return redirect('/login/')
#User
def contractor_action(request):

    tbl1=login()
    username=request.POST.get("username")
    data = {
       'username_exists':      login.objects.filter(username=username).exists(),
        'error':"Username Already Exist"
    }
    if(data["username_exists"]==False):
        tbl1.username=request.POST.get("username")
        password=request.POST.get("password")
        tbl1.password=password
        tbl1.Usertype="Contractor"
        tbl1.status="Not Approved"
        tbl1.save()
        obj=login.objects.get(username=username,password=password)

        u=contractor_register()
        u.login_id = obj.login_id
        u.Name=request.POST.get("Name")
        u.phone_number =request.POST.get("phone")
        u.Email=request.POST.get("Email")
        u.Address=request.POST.get("address")

        licence=request.FILES['licence']
        split_tup = os.path.splitext(licence.name)
        file_extension = split_tup[1]
        # folder path
        dir_path = settings.MEDIA_ROOT
        count = 0
        # Iterate directory
        for path in os.listdir(dir_path):
        # check if current path is a file
            if os.path.isfile(os.path.join(dir_path, path)):
                count += 1
        filecount=count+1
        filename=str(filecount)+"."+file_extension
        obj=FileSystemStorage()
        file=obj.save(filename,licence)
        url1=obj.url(file)
        u.licence=url1
        u.save()
        messages.add_message(request, messages.INFO, 'Registered successfully.')
        return redirect('/contractor_registration/')
    else:
        messages.add_message(request, messages.INFO, 'Registration Failed Username is not Available Sorry.')
        return redirect('/contractor_registration/')
def contractor_home(request):

    if 'suname' in request.session:
        # data=product.objects.filter(quantity__gt=0)
        return render(request,'Contractor/index.html')
    else:
         return redirect('/index/')


def admin_home(request):
    if 'suname' in request.session:
     return render(request,'Master/index.html')
    else:
      return redirect('/index/')
def contractor_registration(request):

    return render(request,'contractor_registration.html')
def login_page(request):

    return render(request,'login.html')
def admin_logout(request):
    logout(request)
    return redirect('/index/')

def display_district(request):
    state_id = request.GET.get("state_id")
    try:

        dist = district.objects.filter(state_id = state_id)
    except Exception:
        data=[]
        data['error_message'] = 'error'
        return JsonResponse(data)
    return JsonResponse(list(dist.values('district_id', 'district')), safe = False)
def display_staff(request):
    district_id = request.GET.get("district_id")
    try:

        dist = staff.objects.filter(district_id = district_id)
    except Exception:
        data=[]
        data['error_message'] = 'error'
        return JsonResponse(data)
    return JsonResponse(list(dist.values('login_id', 'Name')), safe = False)
def check_username(request):
    username = request.GET.get("username")
    data = {
       'username_exists':      login.objects.filter(username=username).exists(),
        'error':"Username Already Exist"
    }
    if(data["username_exists"]==False):
        data["success"]="Available"

    return JsonResponse(data)
def add_staff(request):
    data1 = state.objects.all()
    return render(request,'Master/employee.html',{'data':data1})
def save_staff(request):
    tbl1=login()
    username=request.POST.get("username")
    data = {
       'username_exists':      login.objects.filter(username=username).exists(),
        'error':"Username Already Exist"
    }
    if(data["username_exists"]==False):
        tbl1.username=request.POST.get("username")
        password=request.POST.get("password")
        tbl1.password=password
        tbl1.Usertype="Staff"
        tbl1.status="Approved"
        tbl1.save()
        obj=login.objects.get(username=username,password=password)

        tbl=staff()
        tbl.login_id = obj.login_id
        tbl.firstename=request.POST.get("firstname")
        tbl.lastname=request.POST.get("lastname")
        tbl.address=request.POST.get("address")
        tbl.email_id=request.POST.get("email")
        tbl.dob=request.POST.get("dob")
        tbl.gender=request.POST.get("gender")
        tbl.phone_number=request.POST.get("phone_number")
        tbl.joining_date=request.POST.get("joining_date")
        tbl.qualification=request.POST.get("qualification")
        tbl.desingnation=request.POST.get("designation")
        photo=request.FILES['photo']
        split_tup = os.path.splitext(photo.name)
        file_extension = split_tup[1]
        # folder path
        dir_path = settings.MEDIA_ROOT
        count = 0
        # Iterate directory
        for path in os.listdir(dir_path):
        # check if current path is a file
            if os.path.isfile(os.path.join(dir_path, path)):
                count += 1
        filecount=count+1
        filename=str(filecount)+"."+file_extension
        obj=FileSystemStorage()
        file=obj.save(filename,photo)
        url1=obj.url(file)
        tbl.photo=url1
        tbl.save()
        messages.add_message(request, messages.INFO, 'Registered successfully.')
        return redirect('/add_staff/')
    else:
        messages.add_message(request, messages.INFO, 'Registration Failed Username is not Available Sorry.')
        return redirect('/add_staff/')
def staff_list(request):
 if 'suname' in request.session:
    id=request.session['slogid']
    data=staff.objects.all()
    return render(request,'Master/Employee_list.html',{'data':data})
 else:
      return redirect('/index/')

def delete_staff(request,id):
 if 'suname' in request.session:
    tbl=staff.objects.get(satff_id=id)
    tbl.delete()
    messages.add_message(request, messages.INFO, 'Deleted successfully.')
    return redirect('/staff_list/')
 else:
      return redirect('/index/')

def edit_staff(request,id):
 if 'suname' in request.session:


    data=staff.objects.get(staff_id=id)
    return render(request,'Master/edit_employee.html',{'data':data})
 else:
      return redirect('/index/')
def update_staff(request,id):
    if 'suname' in request.session:
        tbl=staff.objects.get(staff_id=id)
        if len(request.FILES) != 0:

            photo=request.FILES['photo']
            split_tup = os.path.splitext(photo.name)
            file_extension = split_tup[1]
            # folder path
            dir_path = settings.MEDIA_ROOT
            count = 0
            # Iterate directory
            for path in os.listdir(dir_path):
            # check if current path is a file
                if os.path.isfile(os.path.join(dir_path, path)):
                    count += 1
            filecount=count+1
            filename=str(filecount)+"."+file_extension
            obj=FileSystemStorage()
            file=obj.save(filename,photo)
            url1=obj.url(file)
            tbl.photo=url1
        tbl.firstename=request.POST.get("firstname")
        tbl.lastname=request.POST.get("lastname")
        tbl.address=request.POST.get("address")
        tbl.email_id=request.POST.get("email")
        tbl.dob=request.POST.get("dob")
        tbl.gender=request.POST.get("gender")
        tbl.phone_number=request.POST.get("phone_number")
        tbl.joining_date=request.POST.get("joining_date")
        tbl.qualification=request.POST.get("qualification")
        tbl.desingnation=request.POST.get("designation")

        tbl.save()
        messages.add_message(request, messages.INFO, 'Updated successfully.')
        return redirect('/staff_list')
    else:
      return redirect('/index/')


def approve_contractor(request):
   if 'suname' in request.session:
        cursor=connection.cursor()
        cursor.execute("select p.* from  tbl_contractor as p  where p.login_id in (select login_id from tbl_login where Usertype='Contractor' and status='Not Approved')")
        data=cursor.fetchall()
        return render(request,'Master/approve_contractor.html',{'data':data})
   else:
       return redirect('/index/')
def approve(request,id):
    if 'suname' in request.session:
        tbl=login.objects.get(login_id=id)
        tbl.status="Approved"
        tbl.save()
        messages.add_message(request, messages.INFO, 'Updated successfully.')
        return redirect('/approve_contractor/')
    else:
       return redirect('/index/')
def reject(request,id):
    if 'suname' in request.session:
        tbl=login.objects.get(login_id=id)
        tbl.status="Rejected"
        tbl.save()
        messages.add_message(request, messages.INFO, 'Rejected successfully.')
        return redirect('/approve_contractor/')
    else:
        return redirect('/login')

def contractor_list(request):
   if 'suname' in request.session:
            cursor=connection.cursor()
            cursor.execute("select p.* from  tbl_contractor as p  where p.login_id in (select login_id from tbl_login where Usertype='Contractor' and status='Approved')")
            data=cursor.fetchall()
            return render(request,'Master/approved_contractor.html',{'data':data})
   else:
        return redirect('/login')

def save_category(request):
    if 'suname' in request.session:
        id=request.session['slogid']
        tbl=category()
        tbl.category=request.POST.get("category")
        tbl.p_login_id=id
        tbl.save()
        messages.add_message(request, messages.INFO, 'Added successfully.')
        return redirect('/add_category/')
    else:
        return redirect('/login')
def add_category(request):
 if 'suname' in request.session:

    data=category.objects.all()
    return render(request,'Master/category.html',{'data':data})
 else:
      return redirect('/index/')
def edit_category(request,id):
 if 'suname' in request.session:
    data=category.objects.get(category_id=id)
    return render(request,'Master/edit_category.html',{'data':data})
 else:
      return redirect('/index/')
def update_category(request,id):
 if 'suname' in request.session:
    tbl=category.objects.get(category_id=id)
    tbl.category=request.POST.get("category")
    tbl.save()
    messages.add_message(request, messages.INFO, 'Updated successfully.')
    return redirect('/add_category/')
 else:
      return redirect('/index/')
def delete_category(request,id):
 if 'suname' in request.session:
    tbl=category.objects.get(category_id=id)
    tbl.delete()
    messages.add_message(request, messages.INFO, 'Deleted successfully.')
    return redirect('/add_category/')
 else:
      return redirect('/index/')
#product

def user_logout(request):
    logout(request)
    request.session.delete()
    return redirect('/index/')

# ------------------------------------------------------


def save_work_details(request):
    if 'suname' in request.session:
        tbl=work()
        tbl.category_id=request.POST.get("category")
        tbl.work_title=request.POST.get("work_title")
        tbl.description=request.POST.get("description")
        tbl.save()
        messages.add_message(request, messages.INFO, 'Added successfully.')
        return redirect('/add_work_details')
    else:
        return redirect('/index/')
def work_list(request):
    if 'suname' in request.session:



        cursor=connection.cursor()
        cursor.execute("select w.*,c.* from  tbl_work  as w inner join  tbl_category as c  on c.category_id =w.category_id where w.status='Not Assigned'  order by w.entry_date desc")
        data=cursor.fetchall()
        return render(request,'Master/work_list.html',{'data':data})
    else:
       return redirect('/login')
def add_work_details(request):
 if 'suname' in request.session:
    data=category.objects.filter()
    return render(request,'Master/add_work_details.html',{'data':data})
 else:
      return redirect('/index/')
def edit_work(request,id):
 if 'suname' in request.session:
    data1=category.objects.filter()
    data=work.objects.get(work_id=id)
    return render(request,'Master/edit_work.html',{'data':data,'data1':data1})
 else:
      return redirect('/index/')
def update_work(request,id):
 if 'suname' in request.session:
        tbl=work.objects.get(work_id=id)
        tbl.category_id=request.POST.get("category")
        tbl.work_title=request.POST.get("work_title")
        tbl.description=request.POST.get("description")
        tbl.save()
        messages.add_message(request, messages.INFO, 'Updated successfully.')
        return redirect('/work_list')
 else:
      return redirect('/index/')
def delete_work(request,id):
 if 'suname' in request.session:
    tbl=work.objects.get(work_id=id)
    tbl.delete()
    messages.add_message(request, messages.INFO, 'Deleted successfully.')
    return redirect('/work_list')
 else:
      return redirect('/index/')
def save_allot_work(request,id):
    if 'suname' in request.session:

        tbl=work.objects.get(work_id=id)
        tbl.status="Alloted to Staff"
        tbl.staff_login_id=request.POST.get("staff")
        tbl.save()

        messages.add_message(request, messages.INFO, 'Alloted  successfully.')
        return redirect('/work_list/')
    else:
        return redirect('/index/')
def allot_work(request,id):
 if 'suname' in request.session:
    data=staff.objects.all()
    return render(request,'Master/allot_work.html',{'id':id,'data':data})
 else:
      return redirect('/index/')
def alloted_work(request):
    if 'suname' in request.session:



        cursor=connection.cursor()
        cursor.execute("select w.*,c.*, s.firstename, s.lastname,s.phone_number,s.address,s.email_id from  tbl_work  as w inner join tbl_staff as s on s.login_id=w.staff_login_id  inner join  tbl_category as c  on c.category_id =w.category_id where w.status='Alloted to Staff'  order by w.entry_date desc")
        data=cursor.fetchall()
        return render(request,'Master/alloted_work.html',{'data':data})
    else:
       return redirect('/login')
def finish_work(request,id):
 if 'suname' in request.session:
    tbl=work.objects.get(work_id=id)
    tbl.status="Finished"
    tbl.save()
    messages.add_message(request, messages.INFO, 'Updated successfully.')
    return redirect('/alloted_work')
 else:
      return redirect('/index/')


def finished_work(request):
    if 'suname' in request.session:



        cursor=connection.cursor()
        cursor.execute("select w.*,c.*, s.firstename, s.lastname,s.phone_number,s.address,s.email_id from  tbl_work  as w inner join tbl_staff as s on s.login_id=w.staff_login_id  inner join  tbl_category as c  on c.category_id =w.category_id where w.status='Finished'  order by w.entry_date desc")
        data=cursor.fetchall()
        return render(request,'Master/finished_work.html',{'data':data})
    else:
       return redirect('/login')

def Complaint_frm(request):
    if 'suname' in request.session:
        id=request.session['slogid']
        data1 = complaint.objects.filter(user_login_id=id)
        return render(request,'Contractor/complaint.html',{'data1':data1})
    else:
       return redirect('/index/')
def save_complaint(request):
    if 'suname' in request.session:
        tbl=complaint()
        tbl.user_login_id=request.session['slogid']
        tbl.complaint_subject=request.POST.get("subject")
        tbl.complaint=request.POST.get("complaint")
        tbl.reply="No"
        tbl.save()
        messages.add_message(request, messages.INFO, 'Added successfully.')
        return redirect('/Complaint')
    else:
       return redirect('/index/')
def Complaint_list(request):
     if 'suname' in request.session:
        id=request.session['slogid']
        data1 = complaint.objects.filter(user_login_id=id)
        return render(request,'Customer/Complaint_list.html',{'data1':data1})
     else:
       return redirect('/index/')
def delete_complaint(request,id):
    if 'suname' in request.session:
        tbl=complaint.objects.get(complaint_id=id)
        tbl.delete()
        messages.add_message(request, messages.INFO, 'Deleted successfully.')
        return redirect('/Complaint_list')
    else:
       return redirect('/index/')

    # ----------------Admin Complaint -------------
def view_complaints(request):
    if 'suname' in request.session:
        cursor=connection.cursor()
        cursor.execute("select c.*,u.* from  tbl_complaint  as c inner join  tbl_contractor as u  on c.user_login_id =u.login_id where c.reply='No'  order by c.complaint_id desc")
        data=cursor.fetchall()
        return render(request,'Master/view_complaints.html',{'data':data})
    else:
       return redirect('/login')
def replied_list(request):
    if 'suname' in request.session:
        cursor=connection.cursor()
        cursor.execute("select c.*,u.* from  tbl_complaint  as c inner join  tbl_contractor as u  on c.user_login_id =u.login_id where c.reply!='No'  order by c.complaint_id desc")
        data=cursor.fetchall()
        return render(request,'Master/replied_complaints.html',{'data':data})
    else:
       return redirect('/login')
def adm_reply_complaint(request,id):
    if 'suname' in request.session:

        return render(request,'Master/reply_complaint.html',{'id':id})
    else:
       return redirect('/login')
def add_reply(request,id):
    tbl=complaint.objects.get(complaint_id=id)
    tbl.reply=request.POST.get("reply")
    tbl.save()
    return redirect('/replied_contractor_complaint_list/')

# ==============================================

# Public Complaint
def public_complaints(request):

        return render(request,'complaint.html')


def save_public_complaint(request):

        tbl=public_complaint()
        tbl.email=request.POST.get("email")
        tbl.phone=request.POST.get("phone")
        tbl.complaint_subject=request.POST.get("subject")
        tbl.complaint=request.POST.get("complaint")
        tbl.name=request.POST.get("name")
        tbl.save()
        messages.add_message(request, messages.INFO, 'Added successfully.')
        return redirect('/public_complaints/')

def public_admin_complaints(request):
 if 'suname' in request.session:

    data=public_complaint.objects.all()
    return render(request,'Master/public_admin_complaints.html',{'data':data})
 else:
      return redirect('/index/')
def public_staff_complaints(request):
 if 'suname' in request.session:

    data=public_complaint.objects.all()
    return render(request,'Staff/public_staff_complaints.html',{'data':data})
 else:
      return redirect('/index/')
def add_tender(request):
    if 'suname' in request.session:
        data1=category.objects.filter()
        return render(request,'Master/add_tender.html',{'data':data1})
    else:
       return redirect('/index/')

def save_tender(request):
    if 'suname' in request.session:

        tbl=tender()
        tbl.subject=request.POST.get("subject")
        tbl.description=request.POST.get("description")
        tbl.amount=request.POST.get("amount")
        tbl.duedate=request.POST.get("date")
        tbl.category_id=request.POST.get("category")
        tbl.status_tender="Announced"

        image=request.FILES['image']

        split_tup = os.path.splitext(image.name)
        file_extension = split_tup[1]
        # folder path
        dir_path = settings.MEDIA_ROOT
        count = 0
        # Iterate directory
        for path in os.listdir(dir_path):
        # check if current path is a file
            if os.path.isfile(os.path.join(dir_path, path)):
                count += 1
        filecount=count+1
        filename=str(filecount)+"."+file_extension
        obj=FileSystemStorage()
        file=obj.save(filename,image)
        url1=obj.url(file)
        tbl.image=url1

        tbl.save()
        messages.add_message(request, messages.INFO, 'Added successfully.')
        return redirect('/add_tender')
    else:
        return redirect('/index/')
def view_tender(request):
    if 'suname' in request.session:
        cursor=connection.cursor()
        cursor.execute("select w.*,c.* from  tbl_tender  as w inner join  tbl_category as c  on c.category_id =w.category_id where w.status_tender ='Announced'  order by w.entry_date desc")
        data=cursor.fetchall()
        return render(request,'Master/view_tender.html',{'data':data})
    else:
       return redirect('/index/')
def view_customer_tender(request):
    if 'suname' in request.session:
        logid= request.session['slogid']
        cursor=connection.cursor()
        cursor.execute("select t.* from  tbl_tender  as t  where t.duedate >= CURDATE() and t.tender_id not in (select tender_id from tbl_tender_quote where contractor_login_id="+str(logid)+")")
        data=cursor.fetchall()
        cursor.execute("select t.* from  tbl_tender  as t  where t.tender_id  in (select tender_id from tbl_tender_quote where contractor_login_id="+str(logid)+")")
        data2=cursor.fetchall()
        return render(request,'Contractor/view_tender.html',{'data':data,'data2':data2})
    else:
       return redirect('/index/')
def tender_request(request,id):
    if 'suname' in request.session:
        return render(request,'Contractor/tender_request.html',{'id':id})
    else:
       return redirect('/index/')

def save_cust_tender(request,id):
    if 'suname' in request.session:
        logid= request.session['slogid']
        tbl=tender_quote()
        tbl.tender_amount=request.POST.get("amount")
        tbl.tender_id=id
        tbl.contractor_login_id=logid


        tbl.save()
        messages.add_message(request, messages.INFO, 'Added successfully.')
        return redirect('/view_customer_tender/')
    else:
        return redirect('/index/')
def accepted_tenders(request):
    if 'suname' in request.session:
            logid= request.session['slogid']
            cursor=connection.cursor()
            cursor.execute("select t.*,tq.* from  tbl_tender_quote as tq inner join  tbl_tender as t on tq.tender_id=t.tender_id  where t.status_tender='Alloted to Staff' and t.contractor_login_id="+str(logid))
            data=cursor.fetchall()
            return render(request,'Contractor/accepted_tender.html',{'data':data})
    else:
        return redirect('/index/')

def tender_application(request,id):
    if 'suname' in request.session:
            logid= request.session['slogid']
            cursor=connection.cursor()
            cursor.execute("select t.*,tq.*,u.* from  tbl_tender_quote as tq inner join  tbl_tender as t on tq.tender_id=t.tender_id inner join tbl_contractor as u  on tq.contractor_login_id =u.login_id  where tq.tender_id="+str(id)+" and t.duedate >= CURDATE()  and  t.status_tender='Announced' order by tq.tender_amount desc")
            data=cursor.fetchall()
            return render(request,'Master/tender_application.html',{'data':data})
    else:
        return redirect('/index/')
def Allot_tender(request,id):
    if 'suname' in request.session:

        data=staff.objects.all()
        return render(request,'Master/Allot_tender.html',{'id':id,'data':data})

    else:
       return redirect('/login')

def save_allot_tender(request,id):
    if 'suname' in request.session:
        tbl=tender_quote.objects.get(tender_quote_id=id)
        tbl.status=1
        tbl.save()
        tbl=tender_quote.objects.get(tender_quote_id=id)
        cid=tbl.contractor_login_id
        tid=tbl.tender_id
        staff_login_id=request.POST.get("staff")
        t=tender.objects.get(tender_id=tid)
        t.contractor_login_id=cid
        t.staff_login_id=staff_login_id
        t.status_tender="Alloted to Staff"
        t.save()
        messages.add_message(request, messages.INFO, 'Accepted successfully.')
        return redirect('/view_tender/')
    else:
        return redirect('/index/')


def accepted_tender(request,):
    if 'suname' in request.session:
            logid= request.session['slogid']
            cursor=connection.cursor()
            cursor.execute("select t.*,tq.*,u.*,s.* from  tbl_tender_quote as tq inner join  tbl_tender as t on tq.tender_id=t.tender_id inner join  tbl_contractor as u  on tq.contractor_login_id =u.login_id inner join tbl_staff as s on s.login_id = t.staff_login_id where t.status_tender='Alloted to Staff'")
            data=cursor.fetchall()
            return render(request,'Master/accepted_tender.html',{'data':data})
    else:
        return redirect('/index/')

def cust_events(request):
    if 'suname' in request.session:

        data=events.objects.all()
        return render(request,'Customer/events.html',{'data':data})
    else:
       return redirect('/login')
def tender_details(request):
    if 'suname' in request.session:

        cursor=connection.cursor()
        cursor.execute("select t.*,tq.*,p.*,u.* from  tbl_tender_quote as tq inner join  tbl_tender as t on tq.tender_id=t.tender_id inner join  tbl_staff as p  on t.p_login_id =p.login_id inner join  tbl_contractor_register as u  on tq.user_login_id =u.login_id  where t.duedate >= CURDATE()  and tq.tender_id  in (select tender_id from tbl_tender_quote where status=1) order by tq.tender_amount")
        data=cursor.fetchall()
        return render(request,'Master/tender_details.html',{'data':data})
    else:
       return redirect('/login')
def staff_alloted_tender(request):
    if 'suname' in request.session:
        logid= request.session['slogid']
        cursor=connection.cursor()
        cursor.execute("select t.*,tq.*,u.*,s.* from  tbl_tender_quote as tq inner join  tbl_tender as t on tq.tender_id=t.tender_id inner join  tbl_contractor as u  on tq.contractor_login_id =u.login_id inner join tbl_staff as s on s.login_id = t.staff_login_id where t.status_tender='Alloted to Staff' and t.staff_login_id="+str(logid))
        data=cursor.fetchall()
        return render(request,'Staff/staff_alloted_tender.html',{'data':data})
    else:
       return redirect('/login')
def staff_finished_tender(request):
    if 'suname' in request.session:
        logid= request.session['slogid']
        cursor=connection.cursor()
        cursor.execute("select t.*,tq.*,u.*,s.* from  tbl_tender_quote as tq inner join  tbl_tender as t on tq.tender_id=t.tender_id inner join  tbl_contractor as u  on tq.contractor_login_id =u.login_id inner join tbl_staff as s on s.login_id = t.staff_login_id where t.status_tender='Finished' and t.staff_login_id="+str(logid))
        data=cursor.fetchall()
        return render(request,'Staff/staff_finished_tender.html',{'data':data})
    else:
       return redirect('/login')

def staff_review_tender(request,id):
    if 'suname' in request.session:

        data=tender_review.objects.filter(tender_id=id)
        return render(request,'Staff/add_tender_review.html',{'id':id,'data':data})

    else:
       return redirect('/login')
def staff_review(request,id):
    if 'suname' in request.session:

        data=tender_review.objects.filter(tender_id=id)
        return render(request,'Master/staff_review.html',{'id':id,'data':data})

    else:
       return redirect('/login')

def staff_finished_review_tender(request,id):
    if 'suname' in request.session:

        data=tender_review.objects.filter(tender_id=id)
        return render(request,'Staff/staff_finished_review_tender.html',{'data':data})

    else:
       return redirect('/login')

def staff_review_reply_tender(request,id):
    if 'suname' in request.session:


        return render(request,'Master/staff_review_reply_tender.html',{'id':id})

    else:
       return redirect('/login')
def save_tender_work_reply(request,id):
    if 'suname' in request.session:
        t=tender_review.objects.get(tender_review_id=id)
        t.admin_reply=request.POST.get("reply")
        t.save()
        messages.add_message(request, messages.INFO, 'Accepted successfully.')
        return redirect('/accepted_tender/')
    else:
        return redirect('/index/')
def save_tender_work_review(request,id):
    if 'suname' in request.session:
        t=tender_review()
        t.review=request.POST.get("review")
        t.visited_date=request.POST.get("visited_date")
        t.tender_id=id
        t.save()
        messages.add_message(request, messages.INFO, 'Accepted successfully.')
        return redirect('/staff_alloted_tender/')
    else:
        return redirect('/index/')
def view_events(request):
    if 'suname' in request.session:

        data=events.objects.all()
        return render(request,'staff/events.html',{'data':data})
    else:
       return redirect('/login')

# Staff
def staff_alloted_work(request):
    if 'suname' in request.session:
        logid= request.session['slogid']
        cursor=connection.cursor()
        cursor.execute("select w.*,c.*, s.firstename, s.lastname,s.phone_number,s.address,s.email_id from  tbl_work  as w inner join tbl_staff as s on s.login_id=w.staff_login_id  inner join  tbl_category as c  on c.category_id =w.category_id where w.staff_login_id="+str(logid)+"  order by w.entry_date desc")
        data=cursor.fetchall()
        return render(request,'staff/alloted_work.html',{'data':data})

    else:
       return redirect('/login')

#Contractor Update
def contractor_review_tender(request,id):
    if 'suname' in request.session:

        data=tender_update_contractor.objects.filter(tender_id=id)
        return render(request,'Contractor/add_tender_review.html',{'id':id,'data':data})

    else:
       return redirect('/login')
def save_contractor_work_update(request,id):
    if 'suname' in request.session:

        t=tender_update_contractor()
        t.tender_status_details=request.POST.get("review")
        t.visited_date=request.POST.get("visited_date")
        t.tender_id=id
        t.save()
        messages.add_message(request, messages.INFO, 'Added successfully.')
        return redirect('/accepted_tenders/')

    else:
       return redirect('/login')

def finished_contractor_tenders(request):
    if 'suname' in request.session:
            logid= request.session['slogid']
            cursor=connection.cursor()
            cursor.execute("select t.*,tq.* from  tbl_tender_quote as tq inner join  tbl_tender as t on tq.tender_id=t.tender_id  where t.status_tender='Finished' and t.contractor_login_id="+str(logid))
            data=cursor.fetchall()
            return render(request,'Contractor/finished_contractor_tenders.html',{'data':data})
    else:
        return redirect('/index/')

def contractor_review_list(request,id):
    if 'suname' in request.session:

        data=tender_update_contractor.objects.filter(tender_id=id)
        return render(request,'Contractor/contractor_review_list.html',{'data':data})

    else:
       return redirect('/login')

def contractor_progress_details(request,id):
    if 'suname' in request.session:

        data=tender_update_contractor.objects.filter(tender_id=id)
        return render(request,'Master/contractor_progress_details.html',{'id':id,'data':data})

    else:
       return redirect('/login')
def contractor_review_reply_tender(request,id):
    if 'suname' in request.session:


        return render(request,'Master/contractor_review_reply_tender.html',{'id':id})

    else:
       return redirect('/login')

def save_tender_work_update_reply(request,id):
    if 'suname' in request.session:
        t=tender_update_contractor.objects.get(tender_update_id=id)
        t.admin_reply=request.POST.get("reply")
        t.save()
        messages.add_message(request, messages.INFO, 'Updated successfully.')
        return redirect('/accepted_tender/')
    else:
        return redirect('/index/')
def finish_tender_work(request,id):
    if 'suname' in request.session:
        t=tender.objects.get(tender_id=id)
        t.status_tender="Finished"
        t.save()
        messages.add_message(request, messages.INFO, 'Updated successfully.')
        return redirect('/accepted_tender/')
    else:
        return redirect('/index/')

def finished_tender(request,):
    if 'suname' in request.session:
            logid= request.session['slogid']
            cursor=connection.cursor()
            cursor.execute("select t.*,tq.*,u.*,s.* from  tbl_tender_quote as tq inner join  tbl_tender as t on tq.tender_id=t.tender_id inner join  tbl_contractor as u  on tq.contractor_login_id =u.login_id inner join tbl_staff as s on s.login_id = t.staff_login_id where t.status_tender='Finished'")
            data=cursor.fetchall()
            return render(request,'Master/finished_tender.html',{'data':data})
    else:
        return redirect('/index/')

def contractor_progress_details_list(request,id):
    if 'suname' in request.session:

        data=tender_update_contractor.objects.filter(tender_id=id)
        return render(request,'Master/contractor_progress_details_list.html',{'data':data})

    else:
       return redirect('/login')
def staff_review_list(request,id):
    if 'suname' in request.session:

        data=tender.objects.filter(tender_id=id)
        return render(request,'Master/staff_review_list.html',{'data':data})

    else:
       return redirect('/login')