import datetime
from django.db import models

# Create your models here.
# Create your models here.
class login(models.Model):
    login_id=models.AutoField(primary_key=True)
    username=models.CharField(max_length=50)
    password=models.TextField(null=True)
    Usertype=models.CharField(max_length=50)
    status=models.CharField(max_length=50)
    class Meta:
        db_table='tbl_login'
class contractor_register(models.Model):
    contractor_id=models.AutoField(primary_key=True)
    login_id=models.IntegerField()
    Name=models.CharField(max_length=50, null=True)
    phone_number=models.BigIntegerField(null=True)
    Email=models.CharField(max_length=50)
    Address=models.TextField()
    licence=models.CharField(max_length=50)
    class Meta:
        db_table='tbl_contractor'
class state(models.Model):
    state_id=models.AutoField(primary_key=True)
    country_id=models.IntegerField()
    state=models.CharField(max_length=50)
    class Meta:
        db_table='tbl_state'

class district(models.Model):
    district_id=models.AutoField(primary_key=True)
    state_id=models.IntegerField()
    district=models.CharField(max_length=50)
    class Meta:
        db_table='tbl_district'
class staff(models.Model):
    staff_id=models.AutoField(primary_key=True)
    firstename=models.CharField(max_length=50)
    lastname=models.CharField(max_length=50)
    address=models.TextField()
    email_id=models.CharField(max_length=50)
    joining_date=models.DateField()
    dob=models.DateField()
    gender=models.CharField(max_length=50)
    qualification=models.CharField(max_length=50)
    phone_number=models.BigIntegerField(null=True)
    photo=models.CharField(max_length=50)
    desingnation=models.CharField(max_length=50)
    login_id=models.IntegerField()

    class Meta:
        db_table='tbl_staff'
class category(models.Model):
    category_id=models.AutoField(primary_key=True)
    category=models.CharField(max_length=50)

    class Meta:
        db_table='tbl_category'



class complaint(models.Model):
    complaint_id=models.AutoField(primary_key=True)
    complaint_subject=models.CharField(max_length=50)
    complaint=models.CharField(max_length=150)
    user_login_id=models.IntegerField()
    reply=models.CharField(max_length=50)
    class Meta:
        db_table='tbl_complaint'
class feedback(models.Model):
    feedback_id=models.AutoField(primary_key=True)
    feedback_subject=models.CharField(max_length=50)
    feedback=models.CharField(max_length=150)
    staff_login_id=models.IntegerField()
    reply=models.CharField(max_length=50)
    class Meta:
        db_table='tbl_feedback'
class tender(models.Model):
    tender_id=models.AutoField(primary_key=True)
    category_id=models.IntegerField(default=0)
    subject=models.CharField(max_length=50)
    description=models.TextField()
    amount=models.DecimalField(max_digits=12, decimal_places=2, blank=True, null=True)
    entry_date=models.DateTimeField(default=datetime.datetime.now)
    duedate=models.DateField()
    image=models.CharField(max_length=50)
    contractor_login_id=models.IntegerField(default=0)
    staff_login_id=models.IntegerField(default=0)
    status_tender=models.CharField(max_length=50)
    class Meta:
        db_table='tbl_tender'
class tender_quote(models.Model):
    tender_quote_id=models.AutoField(primary_key=True)
    tender_amount=models.DecimalField(max_digits=12, decimal_places=2, blank=True, null=True)
    tender_id=models.IntegerField()
    contractor_login_id=models.IntegerField()
    status=models.IntegerField(default=0)


    class Meta:
        db_table='tbl_tender_quote'
class work(models.Model):
    work_id=models.AutoField(primary_key=True)
    category_id=models.IntegerField(default=0)
    work_title=models.CharField(max_length=50)
    status=models.CharField(max_length=50, default='Not Assigned')
    description=models.TextField()
    entry_date=models.DateTimeField(default=datetime.datetime.now)
    staff_login_id=models.IntegerField(default=0)
    class Meta:
        db_table='tbl_work'
class public_complaint(models.Model):
    public_complaint_id=models.AutoField(primary_key=True)
    complaint_subject=models.CharField(max_length=50)
    complaint=models.CharField(max_length=150)
    name=models.CharField(max_length=50)
    email=models.CharField(max_length=150)
    phone=models.BigIntegerField()
    class Meta:
        db_table='tbl_public_complaint'
class tender_review(models.Model):
    tender_review_id=models.AutoField(primary_key=True)
    review=models.TextField()
    tender_id=models.IntegerField(default=0)
    visited_date=models.DateField()
    admin_reply=models.TextField(null=True, blank=True)
    entry_date=models.DateTimeField(default=datetime.datetime.now)
    class Meta:
        db_table='tbl_tender_review'
class tender_update_contractor(models.Model):
    tender_update_id=models.AutoField(primary_key=True)
    tender_status_details=models.TextField()
    tender_id=models.IntegerField(default=0)
    visited_date=models.DateField()
    admin_reply=models.TextField(null=True, blank=True)
    entry_date=models.DateTimeField(default=datetime.datetime.now)
    class Meta:
        db_table='tbl_tender_update_contractor'