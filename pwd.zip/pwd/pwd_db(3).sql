-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 16, 2023 at 03:03 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.0.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pwd_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `auth_group`
--

CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `auth_group_permissions`
--

CREATE TABLE `auth_group_permissions` (
  `id` bigint(20) NOT NULL,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `auth_permission`
--

CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `auth_permission`
--

INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES
(1, 'Can add log entry', 1, 'add_logentry'),
(2, 'Can change log entry', 1, 'change_logentry'),
(3, 'Can delete log entry', 1, 'delete_logentry'),
(4, 'Can view log entry', 1, 'view_logentry'),
(5, 'Can add permission', 2, 'add_permission'),
(6, 'Can change permission', 2, 'change_permission'),
(7, 'Can delete permission', 2, 'delete_permission'),
(8, 'Can view permission', 2, 'view_permission'),
(9, 'Can add group', 3, 'add_group'),
(10, 'Can change group', 3, 'change_group'),
(11, 'Can delete group', 3, 'delete_group'),
(12, 'Can view group', 3, 'view_group'),
(13, 'Can add user', 4, 'add_user'),
(14, 'Can change user', 4, 'change_user'),
(15, 'Can delete user', 4, 'delete_user'),
(16, 'Can view user', 4, 'view_user'),
(17, 'Can add content type', 5, 'add_contenttype'),
(18, 'Can change content type', 5, 'change_contenttype'),
(19, 'Can delete content type', 5, 'delete_contenttype'),
(20, 'Can view content type', 5, 'view_contenttype'),
(21, 'Can add session', 6, 'add_session'),
(22, 'Can change session', 6, 'change_session'),
(23, 'Can delete session', 6, 'delete_session'),
(24, 'Can view session', 6, 'view_session'),
(25, 'Can add category', 7, 'add_category'),
(26, 'Can change category', 7, 'change_category'),
(27, 'Can delete category', 7, 'delete_category'),
(28, 'Can view category', 7, 'view_category'),
(29, 'Can add complaint', 8, 'add_complaint'),
(30, 'Can change complaint', 8, 'change_complaint'),
(31, 'Can delete complaint', 8, 'delete_complaint'),
(32, 'Can view complaint', 8, 'view_complaint'),
(33, 'Can add contractor_register', 9, 'add_contractor_register'),
(34, 'Can change contractor_register', 9, 'change_contractor_register'),
(35, 'Can delete contractor_register', 9, 'delete_contractor_register'),
(36, 'Can view contractor_register', 9, 'view_contractor_register'),
(37, 'Can add district', 10, 'add_district'),
(38, 'Can change district', 10, 'change_district'),
(39, 'Can delete district', 10, 'delete_district'),
(40, 'Can view district', 10, 'view_district'),
(41, 'Can add feedback', 11, 'add_feedback'),
(42, 'Can change feedback', 11, 'change_feedback'),
(43, 'Can delete feedback', 11, 'delete_feedback'),
(44, 'Can view feedback', 11, 'view_feedback'),
(45, 'Can add login', 12, 'add_login'),
(46, 'Can change login', 12, 'change_login'),
(47, 'Can delete login', 12, 'delete_login'),
(48, 'Can view login', 12, 'view_login'),
(49, 'Can add staff', 13, 'add_staff'),
(50, 'Can change staff', 13, 'change_staff'),
(51, 'Can delete staff', 13, 'delete_staff'),
(52, 'Can view staff', 13, 'view_staff'),
(53, 'Can add state', 14, 'add_state'),
(54, 'Can change state', 14, 'change_state'),
(55, 'Can delete state', 14, 'delete_state'),
(56, 'Can view state', 14, 'view_state'),
(57, 'Can add tender', 15, 'add_tender'),
(58, 'Can change tender', 15, 'change_tender'),
(59, 'Can delete tender', 15, 'delete_tender'),
(60, 'Can view tender', 15, 'view_tender'),
(61, 'Can add tender_quote', 16, 'add_tender_quote'),
(62, 'Can change tender_quote', 16, 'change_tender_quote'),
(63, 'Can delete tender_quote', 16, 'delete_tender_quote'),
(64, 'Can view tender_quote', 16, 'view_tender_quote'),
(65, 'Can add work', 17, 'add_work'),
(66, 'Can change work', 17, 'change_work'),
(67, 'Can delete work', 17, 'delete_work'),
(68, 'Can view work', 17, 'view_work'),
(69, 'Can add public_complaint', 18, 'add_public_complaint'),
(70, 'Can change public_complaint', 18, 'change_public_complaint'),
(71, 'Can delete public_complaint', 18, 'delete_public_complaint'),
(72, 'Can view public_complaint', 18, 'view_public_complaint'),
(73, 'Can add tender_review', 19, 'add_tender_review'),
(74, 'Can change tender_review', 19, 'change_tender_review'),
(75, 'Can delete tender_review', 19, 'delete_tender_review'),
(76, 'Can view tender_review', 19, 'view_tender_review'),
(77, 'Can add tender_update_contractor', 20, 'add_tender_update_contractor'),
(78, 'Can change tender_update_contractor', 20, 'change_tender_update_contractor'),
(79, 'Can delete tender_update_contractor', 20, 'delete_tender_update_contractor'),
(80, 'Can view tender_update_contractor', 20, 'view_tender_update_contractor');

-- --------------------------------------------------------

--
-- Table structure for table `auth_user`
--

CREATE TABLE `auth_user` (
  `id` int(11) NOT NULL,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `auth_user`
--

INSERT INTO `auth_user` (`id`, `password`, `last_login`, `is_superuser`, `username`, `first_name`, `last_name`, `email`, `is_staff`, `is_active`, `date_joined`) VALUES
(1, 'pbkdf2_sha256$390000$KnEDREoVir9tuorDrqyHgA$2RnUeC27F8OL7VlHQHX8Mq4fAThxgh/mEM20l3+1b5s=', NULL, 1, 'admin', '', '', 'admin@gmail.com', 1, 1, '2023-04-08 09:42:22.464994');

-- --------------------------------------------------------

--
-- Table structure for table `auth_user_groups`
--

CREATE TABLE `auth_user_groups` (
  `id` bigint(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `auth_user_user_permissions`
--

CREATE TABLE `auth_user_user_permissions` (
  `id` bigint(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `django_admin_log`
--

CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext DEFAULT NULL,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) UNSIGNED NOT NULL CHECK (`action_flag` >= 0),
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `django_content_type`
--

CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `django_content_type`
--

INSERT INTO `django_content_type` (`id`, `app_label`, `model`) VALUES
(1, 'admin', 'logentry'),
(3, 'auth', 'group'),
(2, 'auth', 'permission'),
(4, 'auth', 'user'),
(5, 'contenttypes', 'contenttype'),
(7, 'pwdapp', 'category'),
(8, 'pwdapp', 'complaint'),
(9, 'pwdapp', 'contractor_register'),
(10, 'pwdapp', 'district'),
(11, 'pwdapp', 'feedback'),
(12, 'pwdapp', 'login'),
(18, 'pwdapp', 'public_complaint'),
(13, 'pwdapp', 'staff'),
(14, 'pwdapp', 'state'),
(15, 'pwdapp', 'tender'),
(16, 'pwdapp', 'tender_quote'),
(19, 'pwdapp', 'tender_review'),
(20, 'pwdapp', 'tender_update_contractor'),
(17, 'pwdapp', 'work'),
(6, 'sessions', 'session');

-- --------------------------------------------------------

--
-- Table structure for table `django_migrations`
--

CREATE TABLE `django_migrations` (
  `id` bigint(20) NOT NULL,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `django_migrations`
--

INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES
(1, 'contenttypes', '0001_initial', '2023-04-08 09:24:19.395256'),
(2, 'auth', '0001_initial', '2023-04-08 09:24:19.796221'),
(3, 'admin', '0001_initial', '2023-04-08 09:24:19.874332'),
(4, 'admin', '0002_logentry_remove_auto_add', '2023-04-08 09:24:19.896463'),
(5, 'admin', '0003_logentry_add_action_flag_choices', '2023-04-08 09:24:19.896463'),
(6, 'contenttypes', '0002_remove_content_type_name', '2023-04-08 09:24:19.990196'),
(7, 'auth', '0002_alter_permission_name_max_length', '2023-04-08 09:24:20.027952'),
(8, 'auth', '0003_alter_user_email_max_length', '2023-04-08 09:24:20.059198'),
(9, 'auth', '0004_alter_user_username_opts', '2023-04-08 09:24:20.059198'),
(10, 'auth', '0005_alter_user_last_login_null', '2023-04-08 09:24:20.112571'),
(11, 'auth', '0006_require_contenttypes_0002', '2023-04-08 09:24:20.112571'),
(12, 'auth', '0007_alter_validators_add_error_messages', '2023-04-08 09:24:20.128193'),
(13, 'auth', '0008_alter_user_username_max_length', '2023-04-08 09:24:20.159450'),
(14, 'auth', '0009_alter_user_last_name_max_length', '2023-04-08 09:24:20.212810'),
(15, 'auth', '0010_alter_group_name_max_length', '2023-04-08 09:24:20.244053'),
(16, 'auth', '0011_update_proxy_permissions', '2023-04-08 09:24:20.244053'),
(17, 'auth', '0012_alter_user_first_name_max_length', '2023-04-08 09:24:20.275296'),
(18, 'pwdapp', '0001_initial', '2023-04-08 09:24:20.375536'),
(19, 'sessions', '0001_initial', '2023-04-08 09:24:20.413291'),
(20, 'pwdapp', '0002_work', '2023-04-08 15:44:10.233680'),
(21, 'pwdapp', '0003_work_staff_login_id_work_status', '2023-04-08 15:54:25.167902'),
(22, 'pwdapp', '0004_remove_category_p_login_id', '2023-04-08 16:09:27.278290'),
(23, 'pwdapp', '0005_tender_category_id', '2023-04-08 18:01:30.468785'),
(24, 'pwdapp', '0006_remove_tender_quote_staff_login_id_and_more', '2023-04-08 18:06:40.377103'),
(25, 'pwdapp', '0007_alter_tender_amount_alter_tender_quote_tender_amount', '2023-04-16 01:28:27.994360'),
(26, 'pwdapp', '0008_public_complaint', '2023-04-16 09:41:27.837644'),
(27, 'pwdapp', '0009_public_complaint_name', '2023-04-16 09:56:16.901531'),
(28, 'pwdapp', '0010_tender_review_tender_update_contractor', '2023-04-16 10:56:43.632629');

-- --------------------------------------------------------

--
-- Table structure for table `django_session`
--

CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `django_session`
--

INSERT INTO `django_session` (`session_key`, `session_data`, `expire_date`) VALUES
('1vnky275bai4vwyhszktvh3yk8m2f48r', 'eyJzdW5hbWUiOiJ0aG9tYXMxMjMiLCJzbG9naWQiOjF9:1pnrP0:qUS1VPLq7AYkWubtWDPK_IMO7wPMVv9E5euTRNXPZt4', '2023-04-30 01:42:02.969790'),
('bu09j7e54vdfktuxujt71sxqagu9m0mg', 'eyJzdW5hbWUiOiJhbnUxMjMiLCJzbG9naWQiOjd9:1plKfH:8QKhnaZBXeXOOvIfN4QsafTLaROshY-Vx4uzsCOb4OI', '2023-04-23 02:20:23.067229');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE `tbl_category` (
  `category_id` int(11) NOT NULL,
  `category` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`category_id`, `category`) VALUES
(1, 'Bridge Development'),
(2, 'Building Construction '),
(4, 'Road');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_complaint`
--

CREATE TABLE `tbl_complaint` (
  `complaint_id` int(11) NOT NULL,
  `complaint_subject` varchar(50) NOT NULL,
  `complaint` varchar(150) NOT NULL,
  `user_login_id` int(11) NOT NULL,
  `reply` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_complaint`
--

INSERT INTO `tbl_complaint` (`complaint_id`, `complaint_subject`, `complaint`, `user_login_id`, `reply`) VALUES
(1, 'Work Progress Support', 'Please Give us good support for  Work', 1, 'Okay');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_contractor`
--

CREATE TABLE `tbl_contractor` (
  `contractor_id` int(11) NOT NULL,
  `login_id` int(11) NOT NULL,
  `Name` varchar(50) DEFAULT NULL,
  `phone_number` bigint(20) DEFAULT NULL,
  `Email` varchar(50) NOT NULL,
  `Address` longtext NOT NULL,
  `licence` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_contractor`
--

INSERT INTO `tbl_contractor` (`contractor_id`, `login_id`, `Name`, `phone_number`, `Email`, `Address`, `licence`) VALUES
(1, 1, 'Thoms Mathew', 9865321245, 'thomas@gmail.com', 'thomas villa ', '/media/39..jpg'),
(2, 2, 'Mathew ', 9865321231, 'mathew@gmail.com', 'mathew villa ', '/media/40..jpg'),
(3, 9, 'Jose', 9865321245, 'jose@gmal.com', 'Jose villa, Adoor', '/media/49..jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_district`
--

CREATE TABLE `tbl_district` (
  `district_id` int(11) NOT NULL,
  `state_id` int(11) NOT NULL,
  `district` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_feedback`
--

CREATE TABLE `tbl_feedback` (
  `feedback_id` int(11) NOT NULL,
  `feedback_subject` varchar(50) NOT NULL,
  `feedback` varchar(150) NOT NULL,
  `staff_login_id` int(11) NOT NULL,
  `reply` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_login`
--

CREATE TABLE `tbl_login` (
  `login_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` longtext DEFAULT NULL,
  `Usertype` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_login`
--

INSERT INTO `tbl_login` (`login_id`, `username`, `password`, `Usertype`, `status`) VALUES
(1, 'thomas123', 'pbkdf2_sha256$390000$mySalt$mn2D0FcF5XCG73y94phLlzfFSzkPI/mGLrtBc9q6iq0=', 'Contractor', 'Approved'),
(2, 'mathew123', 'pbkdf2_sha256$390000$mySalt$9IcLV9gGEmovkrTJD2pkJ/oCOXyxBhygW/UVvtroSWw=', 'Contractor', 'Not Approved'),
(6, 'anju123', 'pbkdf2_sha256$390000$mySalt$vSWkggN5wS5ge2IkX8aSWJuyUGX8zKBQNVdRZTdeozg=', 'Staff', 'Approved'),
(7, 'anu123', 'pbkdf2_sha256$390000$mySalt$qwevcpZX18ybcWGFKnHc2G2CoZi5b4l/1bNNN7Fp1mg=', 'Staff', 'Approved'),
(8, 'jan123', 'pbkdf2_sha256$390000$mySalt$0ljS/b26u699bwUg9VqFep9bD6YZeJ94Soixhf9fD4A=', 'Staff', 'Approved'),
(9, 'jose123', 'pbkdf2_sha256$390000$mySalt$ZPlyCiQDpSGj0V0QmdXTyg7kIPewbOktFqLCyV/0F+c=', 'Contractor', 'Not Approved');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_public_complaint`
--

CREATE TABLE `tbl_public_complaint` (
  `public_complaint_id` int(11) NOT NULL,
  `complaint_subject` varchar(50) NOT NULL,
  `complaint` varchar(150) NOT NULL,
  `email` varchar(150) NOT NULL,
  `phone` bigint(20) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_public_complaint`
--

INSERT INTO `tbl_public_complaint` (`public_complaint_id`, `complaint_subject`, `complaint`, `email`, `phone`, `name`) VALUES
(1, 'Damaged Roads Retaring', 'Damaged Roads Retaring', 'anju@gmail.com', 9858472365, 'chinnu'),
(2, 'Damaged Roads Retaring', 'Damaged Roads Retaring', 'anju@gmail.com', 9858472365, 'Jaison'),
(3, 'poor road condition in my locality', 'please Bring to your notice the poor road condition in my locality', 'aneena@gmail.com', 8596321425, 'john'),
(4, 'Damaged Roads Retaring', 'Bring to your kind attention to poor road conditon', 'aneena@gmail.com', 9858472365, 'Aneena');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_staff`
--

CREATE TABLE `tbl_staff` (
  `staff_id` int(11) NOT NULL,
  `firstename` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `address` longtext NOT NULL,
  `email_id` varchar(50) NOT NULL,
  `joining_date` date NOT NULL,
  `dob` date NOT NULL,
  `gender` varchar(50) NOT NULL,
  `qualification` varchar(50) NOT NULL,
  `phone_number` bigint(20) DEFAULT NULL,
  `photo` varchar(50) NOT NULL,
  `desingnation` varchar(50) NOT NULL,
  `login_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_staff`
--

INSERT INTO `tbl_staff` (`staff_id`, `firstename`, `lastname`, `address`, `email_id`, `joining_date`, `dob`, `gender`, `qualification`, `phone_number`, `photo`, `desingnation`, `login_id`) VALUES
(1, 'Anju', 'Thomas', 'Anju Villa', 'anju@gmail.com', '2023-04-03', '2005-04-07', 'Female', 'MCA', 9865231245, '/media/45..jpg', 'Engineer', 6),
(2, 'Anu', 'Thomas', 'Anu villa, Pathanamthitta', 'anu@gmail.com', '2023-04-03', '2005-04-01', 'Female', 'MCA', 9865321245, '/media/42.jpg', 'Engineer', 7),
(3, 'jan', 'Tom', 'jan villa', 'jan@gmail.com', '2023-04-03', '2005-03-10', 'Male', 'MCA', 8754132659, '/media/43.jpg', 'Engineer', 8);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_state`
--

CREATE TABLE `tbl_state` (
  `state_id` int(11) NOT NULL,
  `country_id` int(11) NOT NULL,
  `state` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tender`
--

CREATE TABLE `tbl_tender` (
  `tender_id` int(11) NOT NULL,
  `subject` varchar(50) NOT NULL,
  `description` longtext NOT NULL,
  `amount` decimal(12,2) DEFAULT NULL,
  `entry_date` datetime(6) NOT NULL,
  `duedate` date NOT NULL,
  `image` varchar(50) NOT NULL,
  `category_id` int(11) NOT NULL,
  `contractor_login_id` int(11) NOT NULL,
  `staff_login_id` int(11) NOT NULL,
  `status_tender` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_tender`
--

INSERT INTO `tbl_tender` (`tender_id`, `subject`, `description`, `amount`, `entry_date`, `duedate`, `image`, `category_id`, `contractor_login_id`, `staff_login_id`, `status_tender`) VALUES
(1, 'Pathamthitta to konni road taring', 'Pathamthitta to konni road taring 18 km .. Retaring', '99999.99', '2023-04-08 23:29:09.872601', '2023-04-21', '/media/46..jpg', 1, 1, 8, 'Finished'),
(2, 'Pathamthitta to vakayar road taring', 'Pathamthitta to vakayar road taring', '99999.99', '2023-04-08 23:32:11.694706', '2023-04-10', '/media/47..jpg', 4, 0, 0, 'Announced'),
(3, 'Pathamthitta to konni road Road Side walk way', 'Pathamthitta to konni road Road Side walk way', '99999.99', '2023-04-08 23:44:17.958399', '2023-04-12', '/media/48..jpg', 2, 0, 0, 'Announced');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tender_quote`
--

CREATE TABLE `tbl_tender_quote` (
  `tender_quote_id` int(11) NOT NULL,
  `tender_amount` decimal(12,2) DEFAULT NULL,
  `tender_id` int(11) NOT NULL,
  `contractor_login_id` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_tender_quote`
--

INSERT INTO `tbl_tender_quote` (`tender_quote_id`, `tender_amount`, `tender_id`, `contractor_login_id`, `status`) VALUES
(1, '100000.00', 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tender_review`
--

CREATE TABLE `tbl_tender_review` (
  `tender_review_id` int(11) NOT NULL,
  `review` longtext NOT NULL,
  `tender_id` int(11) NOT NULL,
  `visited_date` date NOT NULL,
  `admin_reply` longtext DEFAULT NULL,
  `entry_date` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_tender_review`
--

INSERT INTO `tbl_tender_review` (`tender_review_id`, `review`, `tender_id`, `visited_date`, `admin_reply`, `entry_date`) VALUES
(1, '20% completed', 1, '2023-04-16', 'gfhfgh', '2023-04-16 16:27:15.196892'),
(2, 'dfgfdg', 1, '2023-04-10', 'okay', '2023-04-16 16:29:29.074213'),
(3, 'gfg', 1, '2023-04-11', NULL, '2023-04-16 16:33:01.980508');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tender_update_contractor`
--

CREATE TABLE `tbl_tender_update_contractor` (
  `tender_update_id` int(11) NOT NULL,
  `tender_status_details` longtext NOT NULL,
  `tender_id` int(11) NOT NULL,
  `visited_date` date NOT NULL,
  `admin_reply` longtext DEFAULT NULL,
  `entry_date` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_tender_update_contractor`
--

INSERT INTO `tbl_tender_update_contractor` (`tender_update_id`, `tender_status_details`, `tender_id`, `visited_date`, `admin_reply`, `entry_date`) VALUES
(1, 'ghgfgfg gfg', 1, '2023-04-09', 'okay', '2023-04-16 17:45:03.691796'),
(2, 'fhfh', 1, '2023-04-17', NULL, '2023-04-16 17:48:10.171686');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_work`
--

CREATE TABLE `tbl_work` (
  `work_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `work_title` varchar(50) NOT NULL,
  `description` longtext NOT NULL,
  `entry_date` datetime(6) NOT NULL,
  `staff_login_id` int(11) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_work`
--

INSERT INTO `tbl_work` (`work_id`, `category_id`, `work_title`, `description`, `entry_date`, `staff_login_id`, `status`) VALUES
(2, 1, 'Kumbzha Road Re - Taring', 'Kumbzha Road Re - Taring', '2023-04-08 21:15:36.731150', 0, 'Not Assigned'),
(3, 4, 'Padla Road To Khanphala Via Khoda Fala (gravel Roa', 'Padla Road To Khanphala Via Khoda Fala (gravel Road With Cd Works Unger Nrega Scheme)', '2023-04-08 23:17:47.040949', 6, 'Finished'),
(4, 4, 'Road Work adoor to pathanamthitta', 'Road Work adoor to pathanamthitta 18 km', '2023-04-08 23:19:02.229439', 7, 'Alloted to Staff');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `auth_group`
--
ALTER TABLE `auth_group`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  ADD KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`);

--
-- Indexes for table `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`);

--
-- Indexes for table `auth_user`
--
ALTER TABLE `auth_user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  ADD KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`);

--
-- Indexes for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  ADD KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`);

--
-- Indexes for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  ADD KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`);

--
-- Indexes for table `django_content_type`
--
ALTER TABLE `django_content_type`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`);

--
-- Indexes for table `django_migrations`
--
ALTER TABLE `django_migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `django_session`
--
ALTER TABLE `django_session`
  ADD PRIMARY KEY (`session_key`),
  ADD KEY `django_session_expire_date_a5c62663` (`expire_date`);

--
-- Indexes for table `tbl_category`
--
ALTER TABLE `tbl_category`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `tbl_complaint`
--
ALTER TABLE `tbl_complaint`
  ADD PRIMARY KEY (`complaint_id`);

--
-- Indexes for table `tbl_contractor`
--
ALTER TABLE `tbl_contractor`
  ADD PRIMARY KEY (`contractor_id`);

--
-- Indexes for table `tbl_district`
--
ALTER TABLE `tbl_district`
  ADD PRIMARY KEY (`district_id`);

--
-- Indexes for table `tbl_feedback`
--
ALTER TABLE `tbl_feedback`
  ADD PRIMARY KEY (`feedback_id`);

--
-- Indexes for table `tbl_login`
--
ALTER TABLE `tbl_login`
  ADD PRIMARY KEY (`login_id`);

--
-- Indexes for table `tbl_public_complaint`
--
ALTER TABLE `tbl_public_complaint`
  ADD PRIMARY KEY (`public_complaint_id`);

--
-- Indexes for table `tbl_staff`
--
ALTER TABLE `tbl_staff`
  ADD PRIMARY KEY (`staff_id`);

--
-- Indexes for table `tbl_state`
--
ALTER TABLE `tbl_state`
  ADD PRIMARY KEY (`state_id`);

--
-- Indexes for table `tbl_tender`
--
ALTER TABLE `tbl_tender`
  ADD PRIMARY KEY (`tender_id`);

--
-- Indexes for table `tbl_tender_quote`
--
ALTER TABLE `tbl_tender_quote`
  ADD PRIMARY KEY (`tender_quote_id`);

--
-- Indexes for table `tbl_tender_review`
--
ALTER TABLE `tbl_tender_review`
  ADD PRIMARY KEY (`tender_review_id`);

--
-- Indexes for table `tbl_tender_update_contractor`
--
ALTER TABLE `tbl_tender_update_contractor`
  ADD PRIMARY KEY (`tender_update_id`);

--
-- Indexes for table `tbl_work`
--
ALTER TABLE `tbl_work`
  ADD PRIMARY KEY (`work_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `auth_group`
--
ALTER TABLE `auth_group`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_permission`
--
ALTER TABLE `auth_permission`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=81;

--
-- AUTO_INCREMENT for table `auth_user`
--
ALTER TABLE `auth_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `django_content_type`
--
ALTER TABLE `django_content_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `django_migrations`
--
ALTER TABLE `django_migrations`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `tbl_category`
--
ALTER TABLE `tbl_category`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_complaint`
--
ALTER TABLE `tbl_complaint`
  MODIFY `complaint_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_contractor`
--
ALTER TABLE `tbl_contractor`
  MODIFY `contractor_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_district`
--
ALTER TABLE `tbl_district`
  MODIFY `district_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_feedback`
--
ALTER TABLE `tbl_feedback`
  MODIFY `feedback_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_login`
--
ALTER TABLE `tbl_login`
  MODIFY `login_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tbl_public_complaint`
--
ALTER TABLE `tbl_public_complaint`
  MODIFY `public_complaint_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_staff`
--
ALTER TABLE `tbl_staff`
  MODIFY `staff_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_state`
--
ALTER TABLE `tbl_state`
  MODIFY `state_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_tender`
--
ALTER TABLE `tbl_tender`
  MODIFY `tender_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_tender_quote`
--
ALTER TABLE `tbl_tender_quote`
  MODIFY `tender_quote_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_tender_review`
--
ALTER TABLE `tbl_tender_review`
  MODIFY `tender_review_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_tender_update_contractor`
--
ALTER TABLE `tbl_tender_update_contractor`
  MODIFY `tender_update_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_work`
--
ALTER TABLE `tbl_work`
  MODIFY `work_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  ADD CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`);

--
-- Constraints for table `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`);

--
-- Constraints for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  ADD CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  ADD CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  ADD CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  ADD CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  ADD CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  ADD CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
